-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2024 at 11:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upkar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(2) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`admin_id`, `username`, `birthday`, `gender`, `email`, `phone`, `password`, `date`) VALUES
(2, 'username', '2024-06-04', 'M', 'gautamparas112233@gmail.com', 2147483647, '$2y$10$mIa4LCiy/O0424pwNTCYfOfMFqxbqihfO42Se2NcP2UWGGqENXDuW', '2024-06-19 13:02:17');

-- --------------------------------------------------------

--
-- Table structure for table `cart_details`
--

CREATE TABLE `cart_details` (
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(10) NOT NULL,
  `category_title` varchar(100) NOT NULL,
  `category_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_title`, `category_status`) VALUES
(1, 'Groceries', 'Active'),
(2, 'Stationary', 'Active'),
(3, 'Electrical', 'Active'),
(4, 'Kitchen', 'Active'),
(5, 'Drinks', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `chatbot`
--

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL,
  `queries` varchar(300) NOT NULL,
  `replies` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chatbot`
--

INSERT INTO `chatbot` (`id`, `queries`, `replies`) VALUES
(1, 'Hello!', 'Hi there! How can I help you today?'),
(2, 'What is your name?', 'I\'m Chatbot, your virtual assistant.'),
(3, 'How\'s the weather?', 'The weather is great today!'),
(4, 'Tell me a joke.', 'Why don’t scientists trust atoms? Because they make up everything!'),
(5, 'What can you do?', 'I can assist you with various tasks, just ask!'),
(6, 'How are you?', 'I\'m just a bot, but I\'m functioning as expected!'),
(7, 'Where are you from?', 'I\'m from the cloud, here to help you!'),
(8, 'What time is it?', 'I can\'t tell time, but your device surely can!'),
(9, 'Tell me a fun fact.', 'Did you know that honey never spoils?'),
(10, 'How old are you?', 'I don\'t age, I\'m always here to assist you.'),
(11, 'Do you like music?', 'I don\'t have preferences, but music is great!'),
(12, 'What\'s your favorite color?', 'I like all colors equally!'),
(13, 'Can you help me with my homework?', 'Sure, what subject are you working on?'),
(14, 'What\'s your purpose?', 'My purpose is to assist and provide information.'),
(15, 'Who created you?', 'I was created by a team of developers.'),
(16, 'Can you play games?', 'I can certainly help you learn about some games!'),
(17, 'Do you sleep?', 'I don\'t need to sleep, I\'m always active.'),
(18, 'What\'s your favorite movie?', 'I don\'t watch movies, but I can help you find information about them!'),
(19, 'Can you translate languages?', 'Yes, I can help with basic translations.'),
(20, 'What\'s the meaning of life?', 'That\'s a deep question! Many say it\'s 42.'),
(21, 'Can you cook?', 'I can share recipes, but I can\'t cook myself.'),
(22, 'What\'s your favorite book?', 'I don\'t read books, but I can recommend some!'),
(23, 'Can you tell me a story?', 'Once upon a time, there was a curious user who asked a chatbot...'),
(24, 'What\'s your favorite sport?', 'I don\'t play sports, but I can tell you about them.'),
(25, 'Do you have friends?', 'You could say my friends are all the users I help!'),
(26, 'What\'s your favorite food?', 'I don\'t eat, but I can suggest some delicious recipes!'),
(27, 'Can you help me plan a trip?', 'Sure, where would you like to go?'),
(28, 'Do you believe in aliens?', 'The universe is vast, anything is possible!'),
(29, 'Can you solve math problems?', 'Absolutely, just give me a problem to solve.'),
(30, 'What\'s your favorite animal?', 'I think all animals are fascinating!'),
(31, 'Do you like art?', 'Art is a wonderful way to express creativity!'),
(32, 'Can you sing?', 'I can\'t sing, but I can find lyrics for you!'),
(33, 'What\'s your favorite season?', 'I don\'t experience seasons, but they all have their charm!'),
(34, 'Can you write a poem?', 'Roses are red, violets are blue, chat with me, and I\'ll assist you!'),
(35, 'Do you like to dance?', 'I don\'t dance, but I can tell you about different dance styles.'),
(36, 'Can you help me find a job?', 'I can certainly provide tips on job searching!'),
(37, 'What\'s the capital of France?', 'The capital of France is Paris.'),
(38, 'Can you do my taxes?', 'I can\'t do taxes, but I can guide you to resources.'),
(39, 'What\'s your favorite holiday?', 'All holidays are special in their own way!'),
(40, 'Can you drive?', 'I can\'t drive, but I can give you driving directions.'),
(41, 'What\'s your favorite website?', 'I like all websites that provide useful information!'),
(42, 'Do you have a family?', 'You could say my family is the team of developers who created me.'),
(43, 'What\'s your favorite drink?', 'I don\'t drink, but water is essential for life!'),
(44, 'Can you teach me programming?', 'I can certainly provide resources to help you learn programming!'),
(45, 'What\'s your favorite game?', 'I don\'t play games, but I can tell you about popular ones!'),
(46, 'Can you help me shop online?', 'I can help you find what you\'re looking for!'),
(47, 'What\'s your favorite quote?', 'Here\'s a good one: \'The only limit to our realization of tomorrow is our doubts of today.\' - Franklin D. Roosevelt'),
(48, 'Do you like to travel?', 'I don\'t travel, but I can help you plan a trip!'),
(49, 'What\'s the best way to learn a new language?', 'Practice regularly and immerse yourself in the language as much as possible.'),
(50, 'Can you read my mind?', 'I can\'t read minds, but I can understand your queries!'),
(51, 'What\'s your favorite song?', 'I don\'t have a favorite, but music is wonderful!'),
(52, 'Can you help me with a research project?', 'Of course, what topic are you researching?'),
(53, 'What\'s the tallest mountain in the world?', 'Mount Everest is the tallest mountain in the world.'),
(54, 'Do you like puzzles?', 'I enjoy helping people solve puzzles!'),
(55, 'Can you tell me about space?', 'Space is vast and full of wonders, what specifically are you interested in?'),
(56, 'What\'s your favorite TV show?', 'I don\'t watch TV, but I can find show recommendations for you!'),
(57, 'Can you help me with a workout plan?', 'Sure, I can suggest some exercises for you.'),
(58, 'What\'s your favorite hobby?', 'I don\'t have hobbies, but I\'m here to assist you!'),
(59, 'Can you write a song?', 'Sure, let\'s try: \'Chatting with you, making dreams come true, I\'m your assistant, here to help you.\''),
(60, 'Do you like history?', 'History is fascinating and full of lessons.'),
(61, 'Can you help me study?', 'Absolutely, what subject are you studying?'),
(62, 'What\'s your favorite app?', 'I don\'t use apps, but I can suggest some useful ones!'),
(63, 'Do you like nature?', 'Nature is beautiful and important for our planet.'),
(64, 'Can you help me design something?', 'I can provide design tips and resources!'),
(65, 'What\'s the most popular programming language?', 'As of now, Python is very popular.'),
(66, 'Do you like science?', 'Science is amazing and helps us understand the world.'),
(67, 'Can you help me write a resume?', 'Certainly, I can give you tips on crafting a great resume.'),
(68, 'What\'s your favorite video?', 'I don\'t watch videos, but I can help you find some!'),
(69, 'Can you help me find a book?', 'Sure, what genre or author are you looking for?'),
(70, 'What\'s the largest ocean?', 'The Pacific Ocean is the largest ocean.'),
(71, 'Do you like robots?', 'Robots are fascinating and can do many things!'),
(72, 'Can you help me decorate my home?', 'I can give you some decorating tips and ideas!'),
(73, 'What\'s the fastest animal?', 'The cheetah is the fastest land animal.'),
(74, 'Do you like to cook?', 'I don\'t cook, but I can share recipes with you!'),
(75, 'Can you help me make a budget?', 'Absolutely, I can suggest some budgeting tips.'),
(76, 'What\'s the smallest country?', 'Vatican City is the smallest country in the world.'),
(77, 'Do you like to read?', 'I don\'t read, but I can recommend books!'),
(78, 'Can you help me with a science project?', 'Sure, what is your project about?'),
(79, 'What\'s the hottest planet?', 'Venus is the hottest planet in our solar system.'),
(80, 'Do you like sports?', 'Sports are a great way to stay active and have fun!'),
(81, 'Can you help me learn to code?', 'Definitely, I can suggest resources and exercises for coding.'),
(82, 'What\'s the longest river?', 'The Nile River is often considered the longest river in the world.'),
(83, 'Do you like math?', 'Math is a fundamental part of science and technology.'),
(84, 'Can you help me write an essay?', 'Of course, what is your essay about?'),
(85, 'What\'s the most visited city?', 'Bangkok is one of the most visited cities in the world.'),
(86, 'Do you like technology?', 'Technology is amazing and constantly evolving.'),
(87, 'Can you help me find a recipe?', 'Sure, what kind of recipe are you looking for?'),
(88, 'What\'s the biggest desert?', 'The Sahara Desert is the largest hot desert.'),
(89, 'Do you like mysteries?', 'Mysteries are intriguing and fun to solve.'),
(90, 'Can you help me learn about history?', 'Absolutely, what historical period are you interested in?'),
(91, 'What\'s the most spoken language?', 'English is one of the most widely spoken languages globally.'),
(92, 'Do you like traveling?', 'I don\'t travel, but I can help you plan your travels!'),
(93, 'Can you help me find a movie?', 'Sure, what genre are you interested in?'),
(94, 'What\'s the tallest building?', 'The Burj Khalifa in Dubai is the tallest building in the world.'),
(95, 'Do you like animals?', 'Animals are fascinating and diverse.'),
(96, 'Can you help me write a story?', 'I\'d love to! What is your story about?'),
(97, 'What\'s the deepest ocean trench?', 'The Mariana Trench is the deepest ocean trench.'),
(98, 'Do you like to learn?', 'Learning is a wonderful way to grow and understand the world.'),
(99, 'Can you help me with my website?', 'Sure, what do you need help with?'),
(100, 'What\'s the coldest place?', 'Antarctica is the coldest place on Earth.');

-- --------------------------------------------------------

--
-- Table structure for table `order_pending`
--

CREATE TABLE `order_pending` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(255) NOT NULL,
  `order_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_pending`
--

INSERT INTO `order_pending` (`order_id`, `user_id`, `invoice_number`, `product_id`, `quantity`, `order_status`) VALUES
(10, 15, 742137598, 1, 1, 'pending'),
(11, 15, 806205298, 1, 1, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `due_amount` int(255) NOT NULL,
  `invoice_num` int(255) NOT NULL,
  `total_product` int(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_stat` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`order_id`, `user_id`, `due_amount`, `invoice_num`, `total_product`, `order_date`, `order_stat`, `status`) VALUES
(1, 15, 100, 293692464, 1, '2024-06-29 07:46:17', '0', 'Inactive'),
(2, 15, 9700, 986904227, 1, '2024-06-28 13:45:25', 'complete', 'Inactive'),
(3, 15, 9700, 1500116417, 1, '2024-06-29 07:42:43', '0', 'Inactive'),
(4, 15, 100, 557909888, 1, '2024-06-29 07:40:40', 'pending', 'Inactive'),
(5, 15, 1000, 45995291, 1, '2024-06-29 07:40:47', '0', 'Inactive'),
(6, 15, 1000, 1015921324, 1, '2024-06-29 07:50:18', '0', 'Inactive'),
(7, 15, 100, 1885931405, 1, '2024-06-29 07:43:59', '0', 'Inactive'),
(8, 15, 1000, 75838924, 1, '2024-06-29 07:50:15', '0', 'Inactive'),
(9, 15, 1000, 1398301971, 1, '2024-06-29 07:51:13', 'complete', 'Active'),
(10, 15, 100, 1197575980, 1, '2024-06-29 07:53:32', 'pending', 'Active'),
(11, 15, 100, 139587660, 1, '2024-06-29 07:54:43', 'pending', 'Active'),
(12, 15, 100, 44069881, 1, '2024-06-29 07:56:11', 'pending', 'Active'),
(13, 15, 100, 892806173, 1, '2024-06-29 08:02:53', 'pending', 'Active'),
(14, 15, 100, 1072342707, 1, '2024-06-29 08:05:07', 'pending', 'Active'),
(15, 15, 100, 600827432, 1, '2024-06-29 08:06:30', 'pending', 'Active'),
(16, 15, 100, 742137598, 1, '2024-06-29 08:15:11', 'pending', 'Active'),
(17, 15, 100, 806205298, 1, '2024-06-29 08:16:09', 'pending', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `product_keywords` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_image1` varchar(255) NOT NULL,
  `product_image2` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(100) NOT NULL,
  `product_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_description`, `product_keywords`, `category_id`, `product_image1`, `product_image2`, `product_price`, `date`, `status`, `product_status`) VALUES
(1, 'Eclairs', 'ecliars', 'eclairs,chocolate,giftpack', 1, 'ecl.jpg', 'ecliars.jpg', '100', '2024-06-28 13:19:55', 'true', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `detail` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_payment`
--

CREATE TABLE `user_payment` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_num` int(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_stat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_payment`
--

INSERT INTO `user_payment` (`payment_id`, `order_id`, `invoice_num`, `amount`, `payment_mode`, `date`, `payment_stat`) VALUES
(2, 6, 1015921324, 1000, 'Paypal', '2024-06-29 07:34:53', 'Inactive'),
(3, 7, 1885931405, 100, 'Paypal', '2024-06-29 07:37:34', 'Inactive'),
(4, 3, 1500116417, 9700, 'Paypal', '2024-06-29 07:38:34', 'Inactive'),
(5, 5, 45995291, 1000, 'Paypal', '2024-06-29 07:38:48', 'Active'),
(6, 1, 293692464, 100, 'Paypal', '2024-06-29 07:46:17', 'Active'),
(7, 8, 75838924, 1000, 'Paypal', '2024-06-29 07:47:11', 'Active'),
(8, 9, 1398301971, 1000, 'Paypal', '2024-06-29 07:50:05', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `u_email` varchar(100) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_ip` varchar(100) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_mobile` varchar(20) NOT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `account_stat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`uid`, `username`, `u_email`, `u_password`, `user_image`, `user_ip`, `user_address`, `user_mobile`, `reset_token_hash`, `reset_token_expires_at`, `account_stat`) VALUES
(15, 'paras', 'gautamparas112233@gmail.com', '$2y$10$KC9P9.gONfnNHljX5aue5uQCTZmfsEyytiGQ4zGnBvVVV78bXoqrm', 'black_clover.jpg', '::1', 'bhaktapur', '9540957299', NULL, NULL, 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart_details`
--
ALTER TABLE `cart_details`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `cart_details_ibfk_1` (`product_id`),
  ADD KEY `cart_details_ibfk_2` (`ip_address`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `chatbot`
--
ALTER TABLE `chatbot`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_pending`
--
ALTER TABLE `order_pending`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `FK_product` (`product_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `invoice_num` (`invoice_num`),
  ADD KEY `FK_user` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `queries`
--
ALTER TABLE `queries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_payment`
--
ALTER TABLE `user_payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `FK_Payment` (`order_id`),
  ADD KEY `FK_invooice` (`invoice_num`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `user_ip` (`user_ip`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart_details`
--
ALTER TABLE `cart_details`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `chatbot`
--
ALTER TABLE `chatbot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `order_pending`
--
ALTER TABLE `order_pending`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `queries`
--
ALTER TABLE `queries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_payment`
--
ALTER TABLE `user_payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_details`
--
ALTER TABLE `cart_details`
  ADD CONSTRAINT `FK_Productcart` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_cartproduct` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_ipcart` FOREIGN KEY (`ip_address`) REFERENCES `user_table` (`user_ip`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_details_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_details_ibfk_2` FOREIGN KEY (`ip_address`) REFERENCES `user_table` (`user_ip`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_pending`
--
ALTER TABLE `order_pending`
  ADD CONSTRAINT `FK_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_table`
--
ALTER TABLE `order_table`
  ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_id`) REFERENCES `user_table` (`uid`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `user_payment`
--
ALTER TABLE `user_payment`
  ADD CONSTRAINT `FK_Payment` FOREIGN KEY (`order_id`) REFERENCES `order_table` (`order_id`),
  ADD CONSTRAINT `FK_invooice` FOREIGN KEY (`invoice_num`) REFERENCES `order_table` (`invoice_num`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
